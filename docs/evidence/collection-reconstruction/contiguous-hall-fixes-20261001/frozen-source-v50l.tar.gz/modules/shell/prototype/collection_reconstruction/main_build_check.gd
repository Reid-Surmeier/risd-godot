## Run against make_local_fullapp.py's copy, using a real Compatibility renderer.
extends SceneTree

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var app = load("res://modules/shell/demo.tscn").instantiate()
	root.add_child(app)
	for i in 150:
		await process_frame
	var walk = app.find_child("GalleryWalk", true, false)
	assert(walk != null and walk.state().attached)
	walk.set_process(false)
	var failures: Array = []
	var removed := 0
	for mesh in walk._baked_room.find_children("*", "MeshInstance3D", true, false):
		if not mesh.has_meta("far_fixture_clipped"):
			continue
		removed += int(mesh.get_meta("far_fixture_clipped"))
		for surface in mesh.mesh.get_surface_count():
			var arrays = mesh.mesh.surface_get_arrays(surface)
			for index in arrays[Mesh.ARRAY_INDEX]:
				if (mesh.global_transform * arrays[Mesh.ARRAY_VERTEX][index]).z < -walk.L - .19:
					failures.append("Closed demo fixture remains outside Hall")
	if removed == 0:
		failures.append("No demo fixture removed")
	var probes: Dictionary = walk._rooms.get_node("BakedRoom/Lightmap").light_data.get("probe_data")
	if probes.points.size() != 352:
		failures.append("Addition probes lost in full-app conversion")
	for fixture in [[Vector3(1.45, 0, -13), "gallery", false], [Vector3(0, 0, -30.1), "far", true]]:
		walk._pos = fixture[0]
		walk._space = fixture[1]
		walk._update_camera(1.0)
		if walk._baked_room.get_node("Lightmap").visible == fixture[2] or walk._rooms.get_node("BakedRoom/Lightmap").visible != fixture[2] or walk._white_capture.visible:
			failures.append("Visitor must use only its room's probe field")
	if (walk._cam.cull_mask & 1) == 0:
		failures.append("Grey camera cannot see the Hall")
	walk._pos = Vector3(0, 0, -24.5)
	walk._space = "gallery"
	walk._update_camera(1.0)
	if (walk._cam.cull_mask & walk.FAR_LAYER) == 0:
		failures.append("Hall camera cannot see the grey gallery")
	print("MAIN_BUILD_CHECK ", JSON.stringify({"removed_demo_triangles": removed, "probes": probes.points.size(), "failures": failures}))
	quit(0 if failures.is_empty() else 1)

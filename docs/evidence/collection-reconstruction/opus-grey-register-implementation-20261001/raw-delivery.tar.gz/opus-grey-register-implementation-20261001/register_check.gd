## Grey register implementation check (#178/#182), scratch only.
## Dumps what the retained-Hall room scene actually built, then walks every geometry.json trial
## plus the loop in reverse with the scene's own capsule.
##   godot --headless --fixed-fps 60 --path PREPARED --script register_check.gd -- --selfcheck --dump=/abs/scene.json [--trials=/abs/other/geometry.json]
## --trials walks another build's trials and loop in this build (the negative control).
extends SceneTree

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var args:={}
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--") and "=" in arg:args[arg.get_slice("=",0).trim_prefix("--")]=arg.get_slice("=",1)
	var scene=load("res://remodel_room.tscn").instantiate()
	root.add_child(scene)
	assert(scene.qa,"Run with -- --selfcheck")
	var plan:Dictionary=JSON.parse_string(FileAccess.get_file_as_string(args.get("trials","res://geometry.json")))
	if args.has("trials"):
		scene.trials=[]
		for row in plan.trials:scene.trials.append([row[0],scene.vec(row[1]),scene.vec(row[2]),row[3]])
		scene.reset(scene.trials[0][1])
	var route:Array=plan.continuous_loop_waypoints
	for i in range(route.size()-1,0,-1):
		scene.trials.append(["loop_back_%02d"%(route.size()-1-i),Vector3(route[i][0],.25,route[i][1]),Vector3(route[i-1][0],0,route[i-1][1]),false])
	var rows:=[]
	for i in scene.get_child_count():
		describe(scene.get_child(i),scene,str(i),false,"",rows)
	var file:=FileAccess.open(args["dump"],FileAccess.WRITE)
	file.store_string(JSON.stringify({"nodes":rows,"trials":scene.trials.size(),"inventory":scene.inventory}))
	file.close()
	print("REGISTER_DUMP nodes=",rows.size()," trials=",scene.trials.size())
	# The scene's own runner prints DOORWAY_RESULT and quits when the last trial ends.

func describe(node:Node,scene:Node,path:String,hall:bool,wall:String,rows:Array) -> void:
	if node==scene.visitor or node==scene.body or node is Camera3D or node is CanvasLayer:return
	hall=hall or node.name=="ConnectedHall"
	wall=str(node.get_meta("room_wall",wall))
	if node is Node3D:
		var row:={"path":path,"class":node.get_class(),"hall":hall,"wall":wall,"top":not "/" in path}
		var at:Vector3=node.global_position
		if node is MeshInstance3D and node.mesh!=null:
			var box:AABB=node.mesh.get_aabb()
			at=node.global_transform*box.get_center()
			row["mesh"]=[snapped(box.size.x,.0001),snapped(box.size.y,.0001),snapped(box.size.z,.0001),node.mesh.get_surface_count()]
			var m=node.material_override
			row["floor"]=m is ShaderMaterial and m.shader.resource_path.ends_with("floor_oak.gdshader")
			if m is BaseMaterial3D and m.albedo_texture!=null:row["texture"]=m.albedo_texture.resource_path
		if node is CollisionShape3D and node.shape is BoxShape3D:
			var size:Vector3=node.shape.size
			row["box"]=[snapped(size.x,.0001),snapped(size.y,.0001),snapped(size.z,.0001)]
		if node is CollisionShape3D and node.shape is CylinderShape3D:row["cylinder"]=snapped(node.shape.radius,.0001)
		if node is Label3D:row["text"]=node.text
		for key in ["catalogue_asset","catalogue_accession"]:
			if node.has_meta(key):row[key]=str(node.get_meta(key))
		if node.get_script()!=null:row["script"]=node.get_script().resource_path.get_file()
		row["at"]=[snapped(at.x,.0001),snapped(at.y,.0001),snapped(at.z,.0001)]
		var b:Basis=node.global_transform.basis
		row["basis"]=[snapped(b.x.x,.0001),snapped(b.x.z,.0001),snapped(b.z.x,.0001),snapped(b.z.z,.0001),snapped(b.y.y,.0001)]
		rows.append(row)
	for i in node.get_child_count():
		describe(node.get_child(i),scene,path+"/"+str(i),hall,wall,rows)

"""Grey register implementation: prepare, walk and compare in scratch. Nothing is written to root.

    python3 check.py SCRATCH            # SCRATCH must not exist; about three minutes on CPU
    python3 check.py SCRATCH --reuse    # compare again from an earlier SCRATCH

Builds two copies of root's prototype sources (base-source/ = root's four files as received,
and this worktree's four files), runs root's own prepare_main_build_extension.py on each
against the saved Main Hall reference, then runs register_check.gd headless four times:
patched, base, base with the patched build's trials (the negative control), and the patched
sources as the plain prototype project (prepare_remodel.py alone, Hall rebuilt from its sources).
Writes results.json beside this file and exits non-zero if any check fails.
"""
import ast, hashlib, json, os, subprocess, sys
from pathlib import Path

here = Path(__file__).resolve().parent
worktree = here.parents[3]
ROOT = Path("/home/reidsurmeier/orca/workspaces/risd-godot/collection-reconstruction")
MAIN_REFERENCE = Path("/home/reidsurmeier/risd-godot-ingestion/collection-expansion/main-build-reference-20261001")
PROTOTYPE = "modules/shell/prototype/collection_reconstruction"
FOUR = ["prepare_remodel.py", "remodel_room.gd", "remodel_review.gd", "remodel_bake.gd"]
DOOR = [-0.34, 1.5]
CHANGED_ROOMS = ("Rockefeller", "adjacent gallery", "purple elevator-5 connector", "grey French gallery",
                 "Ionic marble-stair threshold study limit", "piano-stair threshold study limit")
checks = {}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(name, ok, detail=""):
    checks[name] = {"ok": bool(ok), "detail": detail}
    print(("ok   " if ok else "FAIL ") + name + (f"  {detail}" if detail else ""))


def godot(project, log, *args):
    with open(log, "w") as out:
        return subprocess.run(["godot", "--headless", "--fixed-fps", "60", "--path", str(project), *args],
                              stdout=out, stderr=subprocess.STDOUT, timeout=1500).returncode


def imported(project, log):
    # Godot's first import of the Hall's lightmap textures sometimes exits non-zero under load; a second pass finishes it.
    return any(godot(project, log, "--import") == 0 for _ in range(3))


def prepare(scratch):
    for name, sources in [("base", here / "base-source"), ("new", worktree / PROTOTYPE)]:
        repo = scratch / f"{name}-repo"
        target = repo / PROTOTYPE
        target.mkdir(parents=True)
        (repo / "image-work").symlink_to(ROOT / "image-work")
        (repo / "modules/shell/prototype/gallery_walk4").symlink_to(ROOT / "modules/shell/prototype/gallery_walk4")
        for path in list((ROOT / PROTOTYPE).glob("*.py")) + list((ROOT / PROTOTYPE).glob("*.gd")):
            (target / path.name).write_bytes((sources / path.name if path.name in FOUR else path).read_bytes())
        out = scratch / f"{name}-out"
        with open(scratch / f"{name}-prepare.log", "w") as log:
            subprocess.run([sys.executable, str(target / "prepare_main_build_extension.py"), str(MAIN_REFERENCE), str(out)],
                           stdout=log, stderr=subprocess.STDOUT, check=True)
        # Hall files as the preparer left them, before Godot rewrites any import metadata.
        hall = json.loads((out / "main-build-source.json").read_text())["source_sha256"]
        (scratch / f"{name}-hall.json").write_text(json.dumps({k: sha(out / k) == v for k, v in hall.items()}))
        assert imported(out, scratch / f"{name}-import.log")
    with open(scratch / "new-plain-prepare.log", "w") as log:
        subprocess.run([sys.executable, str(scratch / "new-repo" / PROTOTYPE / "prepare_remodel.py"), str(scratch / "new-plain")],
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    assert imported(scratch / "new-plain", scratch / "new-plain-import.log")
    script = str(here / "register_check.gd")
    for run, project, extra in [("new", "new-out", []), ("base", "base-out", []), ("new-plain", "new-plain", []),
                                ("base-new-trials", "base-out", [f"--trials={scratch / 'new-out/geometry.json'}"])]:
        code = godot(scratch / project, scratch / f"{run}-walk.log", "--script", script, "--",
                     "--selfcheck", f"--dump={scratch / (run + '-scene.json')}", *extra)
        (scratch / f"{run}-walk.exit").write_text(str(code))
    # The bake script's prepare step on a copy (surfaces, lights and probes only; no lightmap is baked).
    import shutil
    shutil.copytree(scratch / "new-out", scratch / "new-bakeprep")
    code = godot(scratch / "new-bakeprep", scratch / "new-bakeprep.log", "--script", "res://remodel_bake.gd")
    (scratch / "new-bakeprep.exit").write_text(str(code))
    godot(scratch / "new-bakeprep", scratch / "new-bakepositions.log", "--script", str(here / "bake_positions.gd"), "--", f"--out={scratch / 'new-bake-positions.json'}")
    # Root's own floor diagnostic (/tmp/collection-floor-normal-check.gd, copied here unchanged).
    for run in ["new-out", "new-plain", "base-out"]:
        code = godot(scratch / run, scratch / f"{run}-floor.log", "--script", str(here / "root-floor-normal-check.gd"))
        (scratch / f"{run}-floor.exit").write_text(str(code))
    for name in ["remodel_review.gd", "remodel_bake.gd", "remodel_room.gd"]:
        code = godot(scratch / "new-out", scratch / f"parse-{name}.log", "--check-only", "--script", f"res://{name}")
        (scratch / f"parse-{name}.exit").write_text(str(code))


def walk(scratch, run):
    for line in open(scratch / f"{run}-walk.log", errors="replace"):
        if line.startswith("DOORWAY_RESULT "):
            return json.loads(line[len("DOORWAY_RESULT "):])["checks"]
    raise SystemExit(f"{run}: no DOORWAY_RESULT")


def geometry_checks(plan, name):
    rooms = plan["rooms"]
    overlap = [(a["label"], b["label"]) for i, a in enumerate(rooms) for b in rooms[i + 1:]
               if min(a["bounds"][1], b["bounds"][1]) - max(a["bounds"][0], b["bounds"][0]) > 1e-8
               and min(a["bounds"][3], b["bounds"][3]) - max(a["bounds"][2], b["bounds"][2]) > 1e-8]
    record(f"{name}: no two rooms overlap in plan", not overlap, str(overlap))
    # Every opening must have the identical opening in the room on its other side.
    other = {"west": ("east", 0, 1, 2, 3), "east": ("west", 1, 0, 2, 3), "north": ("south", 2, 3, 0, 1), "south": ("north", 3, 2, 0, 1)}
    pairs, unpaired = 0, []
    for a in rooms:
        for side, opening in a["openings"].items():
            opposite, mine, theirs, lo, hi = other[side]
            match = [b for b in rooms if b is not a and abs(b["bounds"][theirs] - a["bounds"][mine]) < 1e-8
                     and b["bounds"][lo] - 1e-8 <= opening[0] and opening[1] <= b["bounds"][hi] + 1e-8]
            if len(match) == 1 and all(abs(x - y) < 1e-8 for x, y in zip(match[0]["openings"].get(opposite, [9e9, 9e9]), opening)):
                pairs += 1
            else:
                unpaired.append(f"{a['label']}:{side}")
    record(f"{name}: all openings paired with the adjoining room", not unpaired and pairs == 26, f"{pairs} opening sides paired {unpaired}")
    return rooms


def register_checks(rooms, plan, name):
    """The register itself. True on the patched build, false on root's base."""
    by = {r["label"]: r for r in rooms}
    grey, rock, link, hall = by["grey French gallery"], by["Rockefeller"], by["purple elevator-5 connector"], by["Grand Gallery"]
    out = {
        "one doorway interval in four places": grey["openings"]["west"] == DOOR == rock["openings"]["east"] == link["openings"]["west"] == link["openings"]["east"] == link["bounds"][2:],
        "south return .30 m beside the grey door": abs(grey["bounds"][3] - grey["openings"]["west"][1] - .30) < 1e-9,
        "Rockefeller z [-5, 1.8], on the Hall north line": rock["bounds"][2:] == [-5.0, 1.8] and rock["bounds"][3] == hall["bounds"][2],
        "European gallery 26.3 m, the Hall's length": abs(by["adjacent gallery"]["bounds"][3] - by["adjacent gallery"]["bounds"][2] - 26.3) < 1e-9 and by["adjacent gallery"]["bounds"][2:] == hall["bounds"][2:],
        "grey west wall 6.0 m inside 5.4..6.6": grey["bounds"][2:] == [-4.2, 1.8],
        "Ionic and piano thresholds on the grey north line": by["Ionic marble-stair threshold study limit"]["bounds"][2:] == [-4.2, 1.8] and by["piano-stair threshold study limit"]["bounds"][2:] == [-5.8, -4.2],
    }
    for label, ok in out.items():
        record(f"{name}: {label}", ok if name == "patched" else not ok, "" if name == "patched" else "negative control: must not hold on root base")
    if name == "patched":
        record("patched: Main Hall bounds and doors unchanged", hall["bounds"] == [.55, 10.55, 1.8, 28.1] and hall["openings"] == {"north": [4.55, 6.55], "south": [3.4355, 7.6645]} or
               (abs(hall["openings"]["north"][0] - 4.55) < 1e-9 and hall["bounds"] == [.55, 10.55, 1.8, 28.1]))
        flags = plan["grey_register"]
        record("patched: metric, calibration, physical-loop and connector-length flags false",
               not any(flags[k] for k in ("metric_accepted", "calibrated_room_metric", "physical_loop_accepted", "connector_length_accepted", "barn_painting_built"))
               and not plan["loop_fit"]["metric_accepted"] and not plan["loop_fit"]["connector_length_accepted"])


def subtrees(dump):
    """Top-level children with their descendants, without flat floor meshes (board counts follow room size)."""
    tops, current = [], None
    for row in dump["nodes"]:
        if row["top"]:
            flat = row["class"] == "MeshInstance3D" and row.get("mesh", [1, 1])[1] < .001
            current = None if flat else [row]
            if current:
                tops.append(current)
        elif current is not None:
            current.append(row)
    return tops


def expected_shift(row):
    """z shift for an object that is not a wall of a changed room, from where root's base had it."""
    x, y, z = row["at"]
    if "mesh" not in row and row["at"] == [0, 0, 0]:  # a holder at the origin; its children carry the place
        return 0.0
    if row["hall"] or row["wall"] or z > 2.5:  # the Hall, any wall of an unchanged room, and everything south
        return 0.0
    if x < 1.75:  # Rockefeller, and the secretary and Delacroix by its door
        return 2.58 if abs(x - 1.48) < .1 and y > 2.9 and z > -2.2 else 2.2  # the vent over the connector door
    if x < 3.85:  # elevator pair and its number keep their offset from the connector's north wall
        return 2.46
    if x < 4.4 and -4.95 < z < -3.75:  # Courbet: 4.86 m from the south-west corner
        return 1.29
    return 1.6 if z < -3.0 else 0.0  # north column, Corot and piano leaves ride the north wall


def scene_checks(base, new):
    a, b = subtrees(base), subtrees(new)
    same_shape = len(a) == len(b) and all(len(x) == len(y) and all(p["class"] == q["class"] for p, q in zip(x, y)) for x, y in zip(a, b))
    record("built scene: same objects in the same order as root base", same_shape, f"{len(a)} / {len(b)} top-level objects")
    if not same_shape:
        return
    moved, exact, walls, wrong, altered = {}, 0, 0, [], []
    for x, y in zip(a, b):
        for p, q in zip(x, y):
            if p["wall"].split(":")[0] in CHANGED_ROOMS:
                walls += 1
                continue
            shift = [round(q["at"][i] - p["at"][i], 4) for i in range(3)]
            want = expected_shift(p)
            if shift != [0, 0, round(want, 4)]:
                wrong.append((p["path"], p["class"], p["at"], shift, want))
            if any(p.get(k) != q.get(k) for k in ("mesh", "box", "cylinder", "basis", "text", "texture", "catalogue_asset", "catalogue_accession", "script")):
                altered.append(p["path"])
            if want:
                moved[want] = moved.get(want, 0) + 1
            else:
                exact += 1
    record("built scene: every object moved by exactly its expected shift, or not at all", not wrong,
           f"moved by z {dict(sorted(moved.items()))}; unmoved and exact {exact}; walls of the six changed rooms {walls}; wrong {wrong[:8]}")
    record("built scene: no mesh, shape, rotation, texture or catalogue tag changed outside those walls", not altered, str(altered[:6]))
    rows = new["nodes"]
    strip = lambda r: {k: v for k, v in r.items() if k != "path"}  # the index path shifts with floor-board counts
    hall_base = [strip(r) for r in base["nodes"] if r["hall"]]
    hall_new = [strip(r) for r in rows if r["hall"]]
    record("retained Hall: 139 native meshes, identical to root base", hall_base == hall_new and sum(r["class"] == "MeshInstance3D" for r in hall_new) == 139,
           f"{len(hall_new)} Hall nodes")

    def spans(tag):
        return sorted([round(r["at"][2] - r["box"][2] / 2, 4), round(r["at"][2] + r["box"][2] / 2, 4)] for r in rows if r["class"] == "CollisionShape3D" and r["wall"] == tag)
    for tag, want in [("grey French gallery:west", [[-4.2, -.34], [1.5, 1.8]]), ("Rockefeller:east", [[-5.0, -.34], [1.5, 1.8]])]:
        record(f"built collision: {tag} leaves the doorway {DOOR}", spans(tag) == want, str(spans(tag)))
    headers = [r for r in rows if r["class"] == "CollisionShape3D" and r["wall"] in ("purple elevator-5 connector:west:header", "purple elevator-5 connector:east:header")]
    record("built collision: both connector headers span the doorway", len(headers) == 2 and all(r["at"][2] == .58 and r["box"][2] == 1.84 for r in headers))
    north = [r["at"][2] for r in rows if r["class"] == "CollisionShape3D" and r["wall"] in
             ("grey French gallery:north", "grey French gallery:north:header", "piano-stair threshold study limit:south:header")]
    record("built collision: grey north wall, its door header and the piano threshold header at z -4.2", north == [-4.2] * 4, str(north))
    panels = [r["at"] for r in rows if r["wall"] == "purple elevator-5 connector:south" and r.get("mesh") == [.49, 2.9, 0, 1]]
    lift = [r["at"] for r in rows if r.get("mesh") == [.49, 2.7, .045, 1]]
    five = [r["at"] for r in rows if r.get("text") == "5"]
    record("connector details inside the moved connector", [p[2] for p in panels] == [1.43] * 4 and [p[2] for p in lift] == [-.27] * 2 and [p[2] for p in five] == [-.23]
           and all(1.7 < p[0] < 3.85 for p in panels + lift + five), f"black panels {len(panels)}, elevator leaves {len(lift)}, number {len(five)}")
    columns = sorted(r["at"] for r in rows if "cylinder" in r)
    record("two columns: north one 1.6 m from the moved north wall, south one unmoved", columns == [[11.05, 1.4, -2.6], [11.05, 1.4, .2]], str(columns))
    art = {tuple(r["at"]) for r in rows if r.get("script") == "painting_asset.gd"}
    want = {"Courbet 43.571": (3.93, 1.8, -3.06), "Corot 24.089": (10.2, 1.8, -4.12), "Bertin 56.214 (unmoved)": (8.7, 1.75, 1.72),
            "Delacroix 35.786": (-5.43, 1.75, 4.35), "Fetti 36.003 (left in place)": (-5.43, 1.8, 8.8), "Goltzius 61.006 (left in place)": (-5.43, 1.75, 14.7),
            "Edwards 58.197": (-1.4, 2.43, -4.82), "Romany 2009.9": (-4.62, 2.12, -2.5)}
    record("paintings at their expected places", all(v in art for v in want.values()), str([k for k, v in want.items() if v not in art]))
    record("Courbet centre 4.86 m from the south-west corner and 1.14 m from the north-west corner", (3.93, 1.8, -3.06) in art and abs(1.8 + 3.06 - 4.86) < 1e-9 and abs(-3.06 + 4.2 - 1.14) < 1e-9)
    far = [r for r in rows if r.get("catalogue_asset") in ("apostle-41046", "apostle-41045", "lion-panel")]
    record("apostles and lion present (their exactness is covered above)", len(far) == 3, str([r["at"] for r in far]))


def main():
    scratch = Path(sys.argv[1]).resolve()
    if "--reuse" not in sys.argv:
        scratch.mkdir(parents=True)
        prepare(scratch)
    # Sources.
    recorded = dict(line.split()[::-1] for line in (here / "base-source/SHA256SUMS").read_text().splitlines())
    record("base-source/ is root's four files as received", all(sha(here / "base-source" / f) == recorded[f] for f in FOUR))
    record("root's four files still equal the recorded baseline", all(sha(ROOT / PROTOTYPE / f) == recorded[f] for f in FOUR), "root has not edited them since")
    ast.parse((worktree / PROTOTYPE / "prepare_remodel.py").read_text())
    record("prepare_remodel.py parses and prepared the project", (scratch / "new-out/geometry.json").exists())
    for name in ["remodel_room.gd", "remodel_review.gd", "remodel_bake.gd"]:
        log = (scratch / f"parse-{name}.log").read_text(errors="replace")
        record(f"{name} parses in Godot 4.7.2", (scratch / f"parse-{name}.exit").read_text() == "0" and "SCRIPT ERROR" not in log and "Parse Error" not in log)
    for run in ["new", "base"]:
        log = (scratch / f"{run}-walk.log").read_text(errors="replace")
        record(f"{run}: scene builds with no script error", "SCRIPT ERROR" not in log and "REMODEL_READY" in log)
    # Plan.
    new_plan = json.loads((scratch / "new-out/geometry.json").read_text())
    base_plan = json.loads((scratch / "base-out/geometry.json").read_text())
    register_checks(geometry_checks(new_plan, "patched"), new_plan, "patched")
    register_checks(geometry_checks(base_plan, "root base"), base_plan, "root base")
    unchanged = [r["label"] for r, s in zip(base_plan["rooms"], new_plan["rooms"]) if r == s]
    record("medieval, Renaissance, Hall, landing, modern and their thresholds unchanged in geometry.json",
           len(base_plan["rooms"]) == len(new_plan["rooms"]) == 13 and len(unchanged) == 7, str(unchanged))
    # Built scene.
    scene_checks(json.loads((scratch / "base-scene.json").read_text()), json.loads((scratch / "new-scene.json").read_text()))
    # Walk.
    new, base, control = walk(scratch, "new"), walk(scratch, "base"), walk(scratch, "base-new-trials")
    failed = lambda r: sorted(k for k, v in r.items() if not v)
    record("walk: patched build fails nothing that root base passes", failed(new) == failed(base),
           f"{len(new)} results; failing in both, in the medieval room only: {failed(new)}")
    joins = [k for k in new if k.startswith(("purple_grey", "grey_", "right_door", "gallery_door", "hall_back_to_grey", "hall_grey_return", "adjacent_gallery", "decorative_room"))]
    # 16 trials (8 joins, each way or its paired trial), each with its camera result.
    record("walk: connector, grey, piano, Ionic, Hall, European and Rockefeller joins pass both ways", len(joins) == 32 and all(new[k] for k in joins), f"{len(joins)} results")
    loop = [k for k in new if k.startswith("loop_")]
    record("walk: retained-Hall loop forward and back passes everywhere root base does", len(loop) == 132 and [k for k in loop if not new[k]] == [k for k in loop if not base[k]] == ["loop_16", "loop_back_16"],
           "33 legs each way; the one leg failing in both builds crosses root's retained portal guard in the medieval room")
    plain = walk(scratch, "new-plain")
    record("walk: plain prototype project, every trial and the loop both ways", len(plain) == 240 and all(plain.values()), f"{len(plain)} results, {len(failed(plain))} failed")
    blocked = [k for k in new if ("blocked" in k or "blocks" in k) and not k.endswith("_camera")]
    record("walk: cases, benches, leaves, grille and the stair void guard still block", len(blocked) == 13 and all(new[k] for k in blocked), str(blocked))
    landing = [k for k in new if k.startswith(("landing_", "modern_", "stairs_door", "tracery", "stone_portal", "iron_grille"))]
    record("walk: landing, modern and medieval-door trials unchanged and passing", all(new[k] and base[k] for k in landing), f"{len(landing)} results")
    lost = sorted(k for k in failed(control) if k not in failed(base) and not k.endswith("_camera"))
    record("negative control: the patched trials cannot be walked in root base", any(k.startswith("purple_grey") for k in lost) and any(k.startswith("loop_") for k in lost) and len(lost) >= 8,
           f"{len(lost)} more failures in root base: {lost}")
    # Floor normals (root's follow-up): board and basket floors must face up; root base does not.
    def floor(run):
        line = [l for l in open(scratch / f"{run}-floor.log", errors="replace") if l.startswith("FLOOR_NORMAL_CHECK ")][0]
        return json.loads(line[len("FLOOR_NORMAL_CHECK "):]), (scratch / f"{run}-floor.exit").read_text()
    for run in ["new-out", "new-plain"]:
        report, code = floor(run)
        record(f"floor normals up in the patched {'retained-Hall' if run == 'new-out' else 'plain'} project (root's diagnostic)",
               report["passed"] and code == "0", f"{report['floor_meshes']} floor meshes, {report['wrong_floor_normals']} wrong normals")
    report, code = floor("base-out")
    record("negative control: root base fails the floor-normal diagnostic", not report["passed"] and code == "1",
           f"{report['floor_meshes']} floor meshes, {report['wrong_floor_normals']} wrong normals")
    trial = Path("/home/reidsurmeier/risd-godot-ingestion/collection-expansion/main-build-rooms-v50d-floor-normal-trial/collection_rooms/remodel_room.gd")
    cut = lambda text: text[text.index("func panel("):text.index("func build_rooms(")]
    record("panel() is root's visually verified trial, line for line", cut(trial.read_text()) == cut((worktree / PROTOTYPE / "remodel_room.gd").read_text()))
    # Bake preparation (not a bake).
    lights = json.loads((scratch / "new-bake-positions.json").read_text())
    inside = lambda p: any(r["bounds"][0] - 1e-6 <= p[0] <= r["bounds"][1] + 1e-6 and r["bounds"][2] - 1e-6 <= p[2] <= r["bounds"][3] + 1e-6 for r in new_plan["rooms"])
    outside = [row for row in lights if row["class"] != "SpotLight3D" and not inside(row["at"])]
    record("bake prepare step runs and every fill light and probe it places is inside a room",
           (scratch / "new-bakeprep.exit").read_text() == "0" and "BAKE_PREPARE surfaces=" in (scratch / "new-bakeprep.log").read_text(errors="replace") and len(lights) > 150 and not outside,
           f"{len(lights)} lights and probes; outside any room: {outside[:4]}; no lightmap was baked")
    # Hall.
    hall = json.loads((scratch / "new-hall.json").read_text())
    source = json.loads((scratch / "new-out/main-build-source.json").read_text())
    record("retained Hall: all 362 source files hash-equal to the saved Hall as prepared", len(hall) == 362 and all(hall.values()))
    still = {k: sha(scratch / "new-out" / k) == v for k, v in source["source_sha256"].items() if not k.endswith(".import")}
    record("retained Hall: every non-import file still hash-equal after the runs", all(still.values()), f"{len(still)} files; Godot may rewrite the other {362 - len(still)} .import files")
    works = json.loads((scratch / "new-out/modules/shell/prototype/gallery_walk4/works.json").read_text())
    record("retained Hall: 23 paintings in its own works.json", len(works) == 23 if isinstance(works, list) else len(works.get("works", works)) == 23)
    main_tree = source["source_worktree"]
    tip = subprocess.check_output(["git", "-C", main_tree, "rev-parse", "HEAD"], text=True).strip()
    dirty = subprocess.check_output(["git", "-C", main_tree, "diff", "HEAD", "--stat", "--", "modules/shell/prototype/gallery_walk4", "modules/shell/assets/collection_frame/page.png"], text=True)
    record("actual Main Hall worktree at the recorded tip, no tracked change", tip == source["source_tip"] and not dirty, tip[:12])
    result = {"checks": checks, "passed": sum(c["ok"] for c in checks.values()), "total": len(checks),
              "patched_sha256": {f: sha(worktree / PROTOTYPE / f) for f in FOUR}, "base_sha256": recorded,
              "walk": {"patched_failed": failed(new), "root_base_failed": failed(base), "patched_plain_project_failed": failed(plain),
                       "root_base_with_patched_trials_failed": failed(control), "results": len(new)},
              "godot": subprocess.check_output(["godot", "--version"], text=True).strip(),
              "not_checked": ["lightmap bake (the saved addition bake does not match the moved surfaces)", "browser export", "production Collection factory", "scripts/check.sh"]}
    (here / "results.json").write_text(json.dumps(result, indent=1) + "\n")
    print(f"\n{result['passed']} of {result['total']} checks passed")
    sys.exit(0 if result["passed"] == result["total"] else 1)


if __name__ == "__main__":
    main()

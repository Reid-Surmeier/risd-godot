## Lists the fill lights, painting spots and probes that remodel_bake.gd's prepare step saved.
## Not a bake: godot --headless --path PREPARED --script bake_positions.gd -- --out=/abs/file.json
extends SceneTree

func _initialize() -> void:
	var out:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):out=arg.trim_prefix("--out=")
	var room:Node=load("res://addition_baked/room.tscn").instantiate()
	var rows:=[]
	for node in room.get_children():
		if node is OmniLight3D or node is SpotLight3D or node is LightmapProbe:
			rows.append({"class":node.get_class(),"at":[snapped(node.position.x,.001),snapped(node.position.y,.001),snapped(node.position.z,.001)]})
	var file:=FileAccess.open(out,FileAccess.WRITE)
	file.store_string(JSON.stringify(rows))
	file.close()
	print("BAKE_POSITIONS ",rows.size())
	room.free()
	quit()

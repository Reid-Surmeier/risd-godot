from pathlib import Path
import subprocess,json
for n in [178,181,182,183]:
 r=subprocess.run(['gh','api','repos/Reid-Surmeier/risd-godot/issues/'+str(n)],capture_output=True,text=True);assert r.returncode==0;v=json.loads(r.stdout);Path('/tmp/collection-'+str(n)+'-live.json').write_text(r.stdout+'\n');print(n,v['state'],v['updated_at'],[x['name'] for x in v['labels']])

from pathlib import Path
from PIL import Image
import json,hashlib,subprocess
app=Path('image-work/collection-room-remodel').resolve()
cli=['node','/home/reidsurmeier/Image-generation-pipline/.tool-builds/1790783219515/scripts/image-pipeline.js']
for kind,ident,accession,video,time,dimensions in [('romanesque-portal','1588546','40.014','IMG_6382',3.75,[4.229,3.861]),('tracery-arch','1428171','40.156.1','IMG_6383',66.25,[1.410,1.092,.273])]:
 assert not (app/f'{kind}-receipt.json').exists(),'Reconcile existing run instead of resubmission'
 refs=[]
 for i,src in enumerate([app/'inventory-catalogue'/f'{kind}-zoom-0.jpg',Path('/tmp/collection-'+('portal' if kind=='romanesque-portal' else 'tracery')+'-native.png')]):
  target=app/'inventory-references'/f'{kind}-selected-{i}.png';Image.open(src).convert('RGB').save(target)
  refs.append({'path':str(target.relative_to(app)),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
 shape='complete paired engaged columns, carved flared capitals, three concentric semicircular stone voussoir bands and a continuous narrow outer carved chevron border; preserve unequal aged stone blocks. Full height from foot blocks to top, low polygon geometry, no invented Gothic point' if kind=='romanesque-portal' else 'ONLY the Gothic pointed top architectural fragment and its small carved end capitals, with the exact asymmetric interlocking trefoil and circular tracery loops in the official reference. Do not include the long column shafts, foot blocks or modern door surround: the accession dimensions refer to the top fragment only'
 prompt=f'Generate ONE FRONT ORTHOGRAPHIC low polygon limestone architecture asset matching RISD {kind}, accession {accession}. Reference 1 is official object detail; reference 2 records its current installed context. Show {shape}. Flat magenta #FF00FF outside silhouette AND inside every opening, including the large walk-through centre and all carved tracery holes. No walls, ceiling, floor, labels, paintings, people, museum background or modern door. Keep creamy weathered limestone, restrained baked shadows, low polygon Main Hall game style. One complete isolated asset, no sheet, perspective or extra views. Native mesh will supply depth and genuinely open walk-through geometry; asset raster must contain only the stone.'
 p=app/f'{kind}-prompt.txt';p.write_text(prompt+'\n');plan={'attempts':[{'id':kind+'-001','prompt':p.name,'promptSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':'1760x1440','inputs':refs}]}
 (app/f'{kind}-plan.json').write_text(json.dumps(plan,indent=2)+'\n');(app/f'{kind}-recipe.json').write_text(json.dumps({'procedure':'edit','plan':kind+'-plan.json','attempt':kind+'-001'})+'\n')
 (app/f'{kind}-source.json').write_text(json.dumps({'catalogue_id':ident,'accession':accession,'source_video':video,'source_time_seconds':time,'catalogue_dimensions_m':dimensions,'dimensions_note':'Portal whole object; tracery top fragment only, shafts and placement are separately inferred','source_role':'shape/material reference, not room albedo','runtime_integrated':False},indent=2)+'\n')
 r=subprocess.run(cli+['prepare','--application',str(app),'--recipe',kind+'-recipe.json','--unit-cost','0.01','--budget','0.01'],capture_output=True,text=True);assert r.returncode==0,r.stdout
 (app/f'{kind}-prepared.json').write_text(r.stdout);objective=json.loads(r.stdout)['objective']
 r=subprocess.run(cli+['image','--application',str(app),'--objective',objective],capture_output=True,text=True);assert r.returncode==0,r.stdout
 (app/f'{kind}-planned.json').write_text(r.stdout);assert json.loads(r.stdout)['_tag']=='Planned'
 Path('/tmp/collection-'+kind+'-plan-result.json').write_text(json.dumps({'kind':kind,'objective':objective}))
 print(kind,objective)

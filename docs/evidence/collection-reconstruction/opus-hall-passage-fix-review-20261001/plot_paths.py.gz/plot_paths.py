"""Plan drawing of my key walks at the Hall door, v50p beside v50r. plot_paths.py <v50p json> <v50r json> <out.png>"""
import json, sys
from PIL import Image, ImageDraw
L=26.3; SC=190; W,Hh=6.0,4.2; X0,Z0=-3.0,-28.9  # metres shown; north (smaller z) at the top
names=['dollhouse-grey-to-hall-from-east','dollhouse-grey-to-hall-from-west','dollhouse-hall-to-grey-from-west','follow-grey-to-hall-forward','follow-grey-to-hall-forward-heading-17deg-east','recess-sideways-east','dollhouse-facing-west-grey-to-hall-south-and-west']
cols=[(214,39,40),(31,119,180),(44,160,44),(148,103,189),(255,127,14),(140,86,75),(23,190,207)]
pw,ph=int(W*SC),int(Hh*SC)
sheet=Image.new('RGB',(pw*2+30,ph+40+18*len(names)),'white'); 
def P(x,z): return (int((x-X0)*SC),int((z-Z0)*SC))
for k,(tag,path) in enumerate([('v50p',sys.argv[1]),('v50r',sys.argv[2])]):
    im=Image.new('RGB',(pw,ph),(250,248,242)); d=ImageDraw.Draw(im)
    for x0,x1 in [(-3,-0.95),(0.95,3)]: d.rectangle([P(x0,-27.06),P(x1,-L)],fill=(205,205,205))
    for x0 in (-0.95,0.905): d.rectangle([P(x0,-27.25),P(x0+0.045,-L)],fill=(70,70,70))
    d.line([P(-3,-L),P(3,-L)],fill=(40,60,140)); 
    for x in range(-30,30,2): d.line([P(x/10,-L+0.55),P(x/10+0.1,-L+0.55)],fill=(40,60,140))
    d.text(P(-2.95,-28.8),'grey gallery',fill=(0,0,0)); d.text(P(-2.95,-26.75),'wall thickness, leaves in dark grey',fill=(60,60,60)); d.text(P(-2.95,-L+0.05),'Hall wall line',fill=(40,60,140)); d.text(P(-2.95,-L+0.6),'0.55 m inside the Hall',fill=(40,60,140)); d.text(P(-2.95,-24.95),'Hall',fill=(0,0,0))
    data=json.load(open(path))
    for i,n in enumerate(names):
        t=[t for t in data['traces'] if t['name']==n][0]
        pts=[P(*t['start'])]+[P(*p) for p in t['path']]
        d.line(pts,fill=cols[i],width=2)
        for p in pts[::3]: d.ellipse([p[0]-2,p[1]-2,p[0]+2,p[1]+2],fill=cols[i])
        e=pts[-1]; d.ellipse([e[0]-5,e[1]-5,e[0]+5,e[1]+5],outline=cols[i],width=2)
    sheet.paste(im,(k*(pw+30),22)); ImageDraw.Draw(sheet).text((k*(pw+30)+4,4),f'{tag}: my key walks at the Hall door, seen from above, north at the top. One dot every third frame; ring = where it ended.',fill=(0,0,0))
    for i,n in enumerate(names):
        t=[t for t in data['traces'] if t['name']==n][0]
        note='' if (t['reached'] or t['group']=='recess') else ', never arrives'
        ImageDraw.Draw(sheet).text((k*(pw+30)+4,ph+28+18*i),f"{n}: largest step {t['largest_step_m']:.3f} m{note}",fill=cols[i])
sheet.save(sys.argv[3]); print(sheet.size)
